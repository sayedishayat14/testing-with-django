from django.shortcuts import render
from .models import Talks

# Create your views here.
def talk_list(request):
    talks = Talks.objects.all()
    return render(request, 'talks/talk_list.html', {'talks' : talks})

def table1(request):
    Tedlist1 = Talks.objects.all()
    return render(request, 'talks/table1.html', {'Tedlist1' : Tedlist1})

def table2(request):
    Tedlist2 = Talks.objects.all()
    return render(request, 'talks/table2.html', {'Tedlist2' : Tedlist2})