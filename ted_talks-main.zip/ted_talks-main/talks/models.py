from django.db import models
from django.utils import timezone

# Create your models here.

class Talks(models.Model):
    Talks_id = models.IntegerField()
    Title = models.TextField()
    Author = models.TextField()
    Date = models.TextField()
    Views = models.IntegerField()
    Likes = models.IntegerField()
    Link = models.TextField()
    created_date = models.DateTimeField(auto_now_add=True)

#We join all of the attributes into a string so that data can be shared by models 
#in foreign keys, and to ensure the relevant parts can be displayed.

    def __str__(self):
        return f'{self.id}, {self.Talks_id}, {self.Title}, {self.Author}, {self.Date},{self.Views}, {self.Likes}, {self.Link}, {self.created_date}'

    