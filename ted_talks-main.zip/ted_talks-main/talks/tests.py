from django.test import Client, TestCase
from django.urls import reverse

# Create your tests here.
class Ted_Tests(TestCase):

    def test_ted_text(self):
        client = Client()
        response = client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Ted Talks")
    
    def test_talks_text(self):
        client = Client()
        response = client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "videos")
    
    def test_view_uses_correct_template(self):
        response = self.client.get(reverse('talk_list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'talks/talk_list.html')
    
