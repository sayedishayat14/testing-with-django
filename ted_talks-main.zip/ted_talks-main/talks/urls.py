from django.urls import path
from . import views

urlpatterns = [
        path('', views.talk_list, name='talk_list'),
        path('table1/', views.table1, name='table1'),
        path('table2/', views.table2, name='table2'),
        ]