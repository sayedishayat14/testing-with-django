# ted_talks

## A group assessment made on Ted Talks.

The ultimate focus is to have ted talk description on the web-based application, which means 
we need to put the datasheet which cleaning it and then data into a database. This means 
creating models that tables in the database using Django object relational mapping library. 
There is a sort of info in the csv file, but we are all only focus on some basic attributes. Currently 
we generate a migration file for Django to use when it loads the model into the schema and 
testing. Although, it execute the correct SQL needed for our database and timestamp would be 
works automatically for us for each new entry. Furthermore, if we will find any kind of designing 
error, we will anytime that you edit the model, need to run make migration and migrate 
commands to have the database changes happen.

Use these commands to start the project.

 pyenv local 3.7.0 # this sets the local version of python to 3.7.0
    python3 -m venv .venv # this creates the virtual environment for you
    source .venv/bin/activate # this activates the virtual environment
    pip install --upgrade pip [ this is optional]  # this installs pip, and upgrades it if required.

    pip install django

This application is very vital for modern day forms of presentations which effective medium to convoy appropriate information to a target people who likes it.Another beneficial part of this application it can showing us anticipated critical think newly and sort of different perspective information  which is a skill that grow our decision making capability.
Basically, we are taken help for our course modules practical session as like polar bears data parse and many more.
